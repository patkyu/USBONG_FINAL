<?php


namespace Includes\baseClasses;

class PlantDeactivate {

	public static function init () {

	}
}